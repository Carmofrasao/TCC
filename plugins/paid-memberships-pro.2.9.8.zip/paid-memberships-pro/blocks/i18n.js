wp.i18n.setLocaleData( { '': {} }, 'paid-memberships-pro' );
