=== Mail Masta ===
Contributors: mailmasta
Donate link: http://getmailmasta.com/
Tags: mail masta, autoresponder, automation, newsletters, campaigns, signup form, newsletter widget, marketing, email, notification, smtp, amazon ses
Requires at least: 3.0.1
Tested up to: 4.0.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Freaking best newsletters, autoresponders, singup forms and reports for WordPress.

== Description ==

We love email marketing, so we made newsletter plugin that is full featured, beautiful and simple to use.= Features =

* Highest deliverability of emails with Amazon SES
* Send and schedule campaigns
* Track opens, clicks and unsubscribes
* Lists of subscribers
* Signup forms
* Track countries
* Personalized mass email
* Full automatization of your site
* Beautiful design
* 24/7 support
* New features will be released regularly

== Installation ==

3 ways to install the plugin:

= 1. lazy approach (search & add) =
1. WordPress Admin > menu Plugins > Add
1. Search for `Mail Masta`
1. Install
1. Activate the plugin
1. A new menu `Mail Masta` will appear in your Admin

= 2. standard approach (upload) =
1. Download the plugin (.zip file) on the right column of this page
1. WordPress Admin > menu Plugins > Add
1. Select the tab "Upload"
1. Upload the .zip file
1. Activate the plugin
1. A new menu `Mail Masta` will appear in your Admin

= 3. hacker approach (FTP) =
1. Upload `mail-masta` folder to the `/wp-content/plugins/` directory through FTP
1. Activate the plugin through the 'Plugins' menu in WordPress
1. A new menu `Mail Masta` will appear in your Admin

== Frequently Asked Questions ==

You can <a href='http://getmailmasta.com/contact/'>ping Akil</a> for any questions. Sorry Akil, I know you hate me now.

== Screenshots ==
1. Overview of email campaigns
2. Report of campaign showing its open, click and unsubscribe rate

3. Second part of campaign report with map info of subscribers, link activity, last 10 opened emails and last 10 clicked links


== Changelog ==

= 1.0.0 =
* After months of hard work finally the release. We are broke, but happy.