<?php
/**
 * Displays a separator preview in payment form edit screen
 *
 * This template can be overridden by copying it to yourtheme/invoicing/payment-forms-admin/previews/separator.php.
 *
 * @version 1.0.19
 */

defined( 'ABSPATH' ) || exit;
?>

<hr class="featurette-divider" />