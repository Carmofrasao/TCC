<div class="panel-body">
<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Your purchase is protected. </font></font><i class="fa fa-lock" aria-hidden="true"></i></p>
</div>