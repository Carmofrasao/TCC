<?php
/**
 * Displays a separator in payment form
 *
 * This template can be overridden by copying it to yourtheme/invoicing/payment-forms/elements/separator.php.
 *
 * @version 1.0.19
 */

defined( 'ABSPATH' ) || exit;
?>
<hr class="featurette-divider" />