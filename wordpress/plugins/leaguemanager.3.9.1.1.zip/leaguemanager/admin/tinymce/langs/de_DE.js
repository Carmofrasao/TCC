// German lang variables for WP2.5

tinyMCE.addI18n({de_DE:{
LeagueManager:{
desc : 'Liga hinzufügen'
}}});
