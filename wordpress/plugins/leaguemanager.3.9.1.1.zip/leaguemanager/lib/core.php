<?php
/**
 * Core class for the WordPress plugin LeagueManager
 * 
 * @author 	Kolja Schleich
 * @package	LeagueManager
 * @copyright 	Copyright 2008-2009
*/
class LeagueManager
{
	/**
	 * array of leagues
	 *
	 * @var array
	 */
	var $leagues = array();
	

	/**
	 * data of certain league
	 *
	 * @var array
	 */
	var $league = array();


	/**
	 * ID of current league
	 *
	 * @var int
	 */
	var $league_id;

	
	/**
	 * current season
	 *
	 * @var mixed
	 */
	var $season;


	/**
	 * error handling
	 *
	 * @var boolean
	 */
	var $error = false;
	
	
	/**
	 * message
	 *
	 * @var string
	 */
	var $message;
	
	
	/**
	 * control variable if bridge is active
	 *
	 * @var boolean
	 */
	var $bridge = false;


	/**
	 * Initializes plugin
	 *
	 * @param boolean $bridge
	 * @return void
	 */
	function __construct( $bridge = false )
	{
		$this->bridge = $bridge;
		if (isset($_GET['league_id'])) {
			$this->setLeagueID( $_GET['league_id'] );
			$this->league = $this->getLeague($this->getLeagueID());
		}

		$this->loadOptions();
	}
	function LeagueManager( $bridge = false )
	{
		$this->__construct( $bridge );
	}
	
	
	/**
	 * load options
	 *
	 * @param none
	 * @return void
	 */
	function loadOptions()
	{
		$this->options = get_option('leaguemanager');
	}
	
	
	/**
	 * get options
	 *
	 * @param none
	 * @return void
	 */
	function getOptions()
	{
		return $this->options;
	}
	
	
	/**
	 * check if bridge is active
	 *
	 * @param none
	 * @return boolean
	 */
	function hasBridge()
	{
		return $this->bridge;
	}
	
	
	/**
	 * set league id
	 *
	 * @param int $league_id
	 * @return void
	 */
	function setLeagueID( $league_id )
	{
		$this->league_id = $league_id;
	}
	
	
	/**
	 * retrieve league ID
	 *
	 * @param none
	 * @return int ID of current league
	 */
	function getLeagueID()
	{
		return $this->league_id;
	}
	

	/**
	 * get current league object
	 *
	 * @param none
	 * @return object
	 */
	function getCurrentLeague()
	{
		return $this->league;
	}
	

	/**
	 * set season
	 *
	 * @param mixed $season
	 * @return void
	 */
	function setSeason( $season )
	{
		$this->season = $season;
	}
	
	
	/**
	 * get current season
	 *
	 * @param mixed $index
	 * @return array
	 */
	function getCurrentSeason( $index = false )
	{
		if ( $index )
			return $this->season[$index];

		return $this->season;
	}


	/**
	 * get league types
	 *
	 * @param none
	 * @return array
	 */
	function getLeagueTypes()
	{
		$types = array( 'other' => __('Other', 'leaguemanager') );
		$types = apply_filters('leaguemanager_sports', $types);
		asort($types);

		return $types;
	}
	
	
	/**
	 * get supported image types from Image class
	 *
	 * @param none
	 * @return array
	 */
	function getSupportedImageTypes()
	{
		return LeagueManagerImage::getSupportedImageTypes();
	}
	
	
	/**
	 * build home only query
	 *
	 * @param int $league_id
	 * @return string MySQL search query
	 */
	function buildHomeOnlyQuery($league_id)
	{
		global $wpdb;
		
		$queries = array();
		$teams = $wpdb->get_results( "SELECT `id` FROM {$wpdb->leaguemanager_teams} WHERE `league_id` = {$league_id} AND `home` = 1" );
		if ( $teams ) {
			foreach ( $teams AS $team )
				$queries[] = "`home_team` = {$team->id} OR `away_team` = {$team->id}";
		
			$query = " AND (".implode(" OR ", $queries).")";
			
			return $query;
		}
		
		return false;
	}
	
	
	/**
	 * get months
	 *
	 * @param none
	 * @return void
	 */
	function getMonths()
	{
		$locale = get_locale();
		setlocale(LC_ALL, $locale);
		for ( $month = 1; $month <= 12; $month++ ) 
			$months[$month] = htmlentities( strftime( "%B", mktime( 0,0,0, $month, date("m"), date("Y") ) ) );
			
		return $months;
	}
	
	
	/**
	 * returns image directory
	 *
	 * @param string|false $file
	 * @return string
	 */
	function getImagePath( $file = false )
	{
		$league = $this->getCurrentLeague();
		if ( $file ) 
			return trailingslashit($_SERVER['DOCUMENT_ROOT']) . substr($file,strlen($_SERVER['HTTP_HOST'])+8, strlen($file));
		 else 
			return ABSPATH . $league->upload_dir;
	}
	
	
	/**
	 * returns url of image directory
	 *
	 * @param string|false $file image file
	 * @return string
	 */
	function getImageUrl( $file = false )
	{
		$league = $this->getCurrentLeague();
		if ( $file )
			return trailingslashit(get_option('siteurl')) . $league->upload_dir . $file;
		else
			return trailingslashit(get_option('siteurl')) . $league->upload_dir;
	}

	
	/**
	 * get Thumbnail image
	 *
	 * @param string $file
	 * @return string
	 */
	function getThumbnailUrl( $file )
	{
		if ( file_exists($this->getThumbnailPath($file)) )
			return trailingslashit(dirname($file)) . 'thumb_' . basename($file);
		else
			return trailingslashit(dirname($file)) . 'thumb.' . basename($file);
	}

	
	/**
	 * get Thumbnail path
	 *
	 * @param string $file
	 * @return string
	 */
	function getThumbnailPath( $file )
	{
		return trailingslashit($_SERVER['DOCUMENT_ROOT']) . dirname(substr($file,strlen($_SERVER['HTTP_HOST'])+8, strlen($file))) . '/thumb_' . basename($file);
	}
	
	
	/**
	 * set message
	 *
	 * @param string $message
	 * @param boolean $error triggers error message if true
	 * @return none
	 */
	function setMessage( $message, $error = false )
	{
		$type = 'success';
		if ( $error ) {
			$this->error = true;
			$type = 'error';
		}
		$this->message[$type] = $message;
	}
	
	
	/**
	 * return message
	 *
	 * @param none
	 * @return string
	 */
	function getMessage()
	{
		if ( $this->error )
			return $this->message['error'];
		else
			return $this->message['success'];
	}
	
	
	/**
	 * print formatted message
	 *
	 * @param none
	 * @return string
	 */
	function printMessage()
	{
		if ( $this->error )
			echo "<div class='error'><p>".$this->getMessage()."</p></div>";
		else
			echo "<div id='message' class='updated fade'><p><strong>".$this->getMessage()."</strong></p></div>";
	}

	
	/**
	 * Set match day
	 *
	 * @param int 
	 * @return void
	 */
	function setMatchDay( $match_day )
	{
		$this->match_day = $match_day;
	}
	
	
	/**
	* retrieve match day
	 *
	 * @param none
	 * @return int
	 */
	function getMatchDay( $select = '' )
	{
		global $wpdb;
		
		$season = isset($this->season['name']) ? $this->season['name'] : '';
		if ( isset($_GET['match_day']) ) {
			$match_day = (int)$_GET['match_day'];
		} elseif ( isset($this->match_day) && $this->match_day != -1) {
			$match_day = $this->match_day;
		} elseif (isset($_POST['match_day'])) {
			$match_day = $_POST['match_day'];
		} elseif ( $select == "last" ) {
			$sql = "SELECT `match_day`, DATEDIFF(NOW(), `date`) AS datediff FROM {$wpdb->leaguemanager_matches} WHERE `league_id` = '%d' AND `season` = '%d' AND DATEDIFF(NOW(), `date`) > 0 ORDER BY datediff ASC";
			$matches = $wpdb->get_results( $wpdb->prepare($sql, $this->league_id, $season) );
			if ($matches[0]) $match_day = $matches[0]->match_day;
			else $match_day = -1;
		} elseif ( $select == "next" ) {
			$sql = "SELECT `match_day`, DATEDIFF(NOW(), `date`) AS datediff FROM {$wpdb->leaguemanager_matches} WHERE `league_id` = '%d' AND `season` = '%d' AND DATEDIFF(NOW(), `date`) < 0 ORDER BY datediff DESC";
			$matches = $wpdb->get_results( $wpdb->prepare($sql, $this->league_id, $season) );
			if ($matches[0]) $match_day = $matches[0]->match_day;
			else $match_day = -1;
		} elseif ( $select == "current" || $select == "latest") {
			$sql = "SELECT `id`, `match_day`, DATEDIFF(NOW(), `date`) AS datediff FROM {$wpdb->leaguemanager_matches} WHERE `league_id` = '%d' AND `season` = '%d' ORDER BY datediff ASC";
			$matches = $wpdb->get_results( $wpdb->prepare($sql, $this->league_id, $season) );
			if ($matches) {
				$datediff = array();
				foreach ($matches AS $key => $match) {
					$datediff[$key] = abs($match->datediff);
				}
				asort($datediff);
				$keys = array_keys($datediff);
				$match_day = $matches[$keys[0]]->match_day;
			} else {
				$match_day = -1;
			}
		} else {
			$match_day = -1;
		}
		
		$this->setMatchDay($match_day);
		
		return $match_day;
	}
	
	
	/**
	 * get current season
	 *
	 * @param object $league
	 * @param mixed $season
	 * @return array
	 */
	function getSeason( $league, $season = false, $index = false )
	{
		if ( isset($_GET['season']) && !empty($_GET['season']) )
			$data = $league->seasons[$_GET['season']];
		elseif ( $season )
			$data = $league->seasons[$season];
		elseif ( !empty($league->seasons) )
			$data = end($league->seasons);
		else
			return false;

		if ( $index )
			return $data[$index];
		else
			return $data;
	}


	/**
	 * get leagues from database
	 *
	 * @param int $league_id (default: false)
	 * @param string $search
	 * @return array
	 */
	function getLeagues( $offset=0, $limit=99999999 )
	{
		global $wpdb;
		
		$leagues = $wpdb->get_results($wpdb->prepare( "SELECT `title`, `id`, `settings`, `seasons` FROM {$wpdb->leaguemanager} ORDER BY id ASC LIMIT %d, %d", $offset, $limit ));
		$i = 0;
		foreach ( $leagues AS $league ) {
			$leagues[$i]->seasons = $league->seasons = maybe_unserialize($league->seasons);
			$league->settings = maybe_unserialize($league->settings);

			$leagues[$i] = (object)array_merge((array)$league,(array)$league->settings);
			unset($leagues[$i]->settings, $league->settings);

			$this->leagues[$league->id] = $league;
			$i++;
		}
		return $leagues;
	}
	
	
	/**
	 * get league
	 *
	 * @param mixed $league_id either ID of League or title
	 * @return league object
	 */
	function getLeague( $league_id )
	{
		global $wpdb;
		
		$league = $wpdb->get_results( "SELECT `title`, `id`, `seasons`, `settings` FROM {$wpdb->leaguemanager} WHERE `id` = '".(int)$league_id."' OR `title` = '".$league_id."'" );
		$league[] = new stdClass();
		$league = $league[0];
		$league->seasons = maybe_unserialize($league->seasons);
		$league->settings = (array)maybe_unserialize($league->settings);

		$this->league_id = $league->id;
		$league->hasBridge = $this->hasBridge();

		$league = (object)array_merge((array)$league,(array)$league->settings);
		unset($league->settings);

		$this->league = $league;
		return $league;
	}
	
	
	/**
	 * get teams from database
	 *
	 * @param string $search search string for WHERE clause.
	 * @param string $output OBJECT | ARRAY
	 * @return array database results
	 */
	function getTeams( $search, $orderby = false, $output = 'OBJECT' )
	{
		global $wpdb;
		
		if ( !empty($search) ) $search = " WHERE $search";
		if ( !$orderby ) $orderby = "`rank` ASC, `id` ASC";

		$teamlist = $wpdb->get_results( "SELECT `title`, `website`, `coach`, `stadium`, `logo`, `home`, `group`, `roster`, `points_plus`, `points_minus`, `points2_plus`, `points2_minus`, `add_points`, `done_matches`, `won_matches`, `draw_matches`, `lost_matches`, `diff`, `league_id`, `id`, `season`, `rank`, `status`, `custom` FROM {$wpdb->leaguemanager_teams} $search ORDER BY $orderby" );
		$teams = array(); $i = 0;
		foreach ( $teamlist AS $team ) {
			$team->custom = maybe_unserialize($team->custom);
			if ( 'ARRAY' == $output ) {
				$teams[$team->id]['title'] = htmlspecialchars(stripslashes($team->title), ENT_QUOTES);
				$teams[$team->id]['rank'] = $team->rank;
				$teams[$team->id]['status'] = $team->status;
				$teams[$team->id]['season'] = $team->season;
				$teams[$team->id]['website'] = $team->website;
				$teams[$team->id]['coach'] = $team->coach;
				$teams[$team->id]['stadium'] = $team->stadium;
				$teams[$team->id]['logo'] = $team->logo;
				$teams[$team->id]['home'] = $team->home;
				$teams[$team->id]['group'] = $team->group;
				$teams[$team->id]['roster'] = maybe_unserialize($team->roster);
				if ( $this->hasBridge() ) {
					global $lmBridge;
					$teams[$team->id]['teamRoster'] = $lmBridge->getTeamRoster(maybe_unserialize($team->roster));
				}
				$teams[$team->id]['points'] = array( 'plus' => $team->points_plus, 'minus' => $team->points_minus );
				$teams[$team->id]['points2'] = array( 'plus' => $team->points2_plus, 'minus' => $team->points2_minus );
				$teams[$team->id]['add_points'] = $team->add_points;
				foreach ( (array)$team->custom AS $key => $value )
					$teams[$team->id][$key] = $value;
			} else {
				$teamlist[$i]->roster = maybe_unserialize($team->roster);
				if ( $this->hasBridge() ) {
					global $lmBridge;
					$teamlist[$i]->teamRoster = $lmBridge->getTeamRoster(maybe_unserialize($team->roster));
				}
				$teamlist[$i]->title = htmlspecialchars(stripslashes($team->title), ENT_QUOTES);
				$teamlist[$i] = (object)array_merge((array)$team, (array)$team->custom);
			}

			unset($teamlist[$i]->custom, $team->custom);
			$i++;
		}

		if ( 'ARRAY' == $output )
			return $teams;

		return $teamlist;
	}
	
	
	/**
	 * get single team
	 *
	 * @param int $team_id
	 * @return object
	 */
	function getTeam( $team_id )
	{
		global $wpdb;

		$team = $wpdb->get_results( "SELECT `title`, `website`, `coach`, `stadium`, `logo`, `home`, `group`, `roster`, `points_plus`, `points_minus`, `points2_plus`, `points2_minus`, `add_points`, `done_matches`, `won_matches`, `draw_matches`, `lost_matches`, `diff`, `league_id`, `id`, `season`, `rank`, `status`, `custom` FROM {$wpdb->leaguemanager_teams} WHERE `id` = '".$team_id."' ORDER BY `rank` ASC, `id` ASC" );
		
		if (!isset($team[0])) return false;
		
		$team = $team[0];

		$team->title = htmlspecialchars(stripslashes($team->title), ENT_QUOTES);
		$team->custom = maybe_unserialize($team->custom);
		$team->roster = maybe_unserialize($team->roster);
		if ( $this->hasBridge() ) {
			global $lmBridge;
			$team->teamRoster = $lmBridge->getTeamRoster($team->roster);
		}

		$team = (object)array_merge((array)$team,(array)$team->custom);
		unset($team->custom);
		
		return $team;
	}
	
	
	/**
	 * get number of seasons
	 *
	 * @param array $seasons
	 * @return int
	 */
	function getNumSeasons( $seasons )
	{
		if (empty($seasons))
			return 0;
		else
			return count($seasons);
	}


	/**
	 * gets number of teams for specific league
	 *
	 * @param int $league_id
	 * @return int
	 */
	function getNumTeams( $league_id, $group = '' )
	{
		global $wpdb;
		if($group == ''){
			$num_teams = $wpdb->get_var( "SELECT COUNT(ID) FROM {$wpdb->leaguemanager_teams} WHERE `league_id` = '".$league_id."'" );
		} else {
			$num_teams = $wpdb->get_var( "SELECT COUNT(ID) FROM {$wpdb->leaguemanager_teams} WHERE `league_id` = '".$league_id."'AND `group` = '".$group."'" );
		}
		return $num_teams;
	}
	
		
	/**
	 * check if any team has a team roster
	 *
	 * @param array $teams
	 * @return boolean
	 */
	function hasTeamRoster($teams)
	{
		foreach ($teams AS $team) {
			if (!empty($team->teamRoster)) return true;
		}
		return false;
	}
	
	
	/**
	 * gets number of matches
	 *
	 * @param string $search
	 * @return int
	 */
	function getNumMatches( $league_id )
	{
		global $wpdb;
	
		$num_matches = $wpdb->get_var( "SELECT COUNT(ID) FROM {$wpdb->leaguemanager_matches} WHERE `league_id` = '".$league_id."'" );
		return $num_matches;
	}
	
		
	/**
	 * rank teams
	 *
	 * The Team Ranking can be altered by sport specific rules via the hook <em>rank_teams_`sport_type`</em>
	 * `sport_type` needs to be the key of current sport type. Below is an example how it could be used
	 *
	 * add_filter('rank_teams_soccer', 'soccer_ranking');
	 *
	 * function soccer_ranking( $teams ) {
	 *	// do some stuff
	 *	return $teams
	 * }
	 *
	 *
	 * @param int $league_id
	 * @param mixed $season
	 * @param boolean $update
	 * @return array $teams ordered
	 */
	function rankTeams( $league_id )
	{
		global $wpdb;
		$league = $this->getLeague( $league_id );
                                    
		if ( !isset($season) )
			$season = $this->getSeason($league);

		$season = is_array($season) ? $season['name'] : $season;

		// rank Teams in groups
		$groups = !empty($league->groups) ? explode(";", $league->groups) : array( '' );

		foreach ( $groups AS $group ) {
			$search = "`league_id` = '".$league_id."' AND `season` = '".$season."'";
			if ( !empty($group) ) $search .= " AND `group` = '".$group."'";

			$teams = $teamsTmp = array();
			foreach ( $this->getTeams( $search ) AS $team ) {
				$team->diff = ( $team->diff > 0 ) ? '+'.$team->diff : $team->diff;
				$team->points = array( 'plus' => $team->points_plus, 'minus' => $team->points_minus );
				$team->points2 = array( 'plus' => $team->points2_plus, 'minus' => $team->points2_minus );
				$team->winPercent = ($team->done_matches > 0) ? ($team->won_matches/$team->done_matches) * 100 : 0;

				$teams[] = $team;
				$teamsTmp[] = $team;
			}
		
			if ( !empty($teams) && $league->team_ranking == 'auto' ) {
				if ( has_filter( 'rank_teams_'.$league->sport ) ) {
					$teams = apply_filters( 'rank_teams_'.$league->sport, $teams );
				} else {
					foreach ( $teams AS $key => $row ) {
						$points[$key] = $row->points['plus'] + $row->add_points;
						$done[$key] = $row->done_matches;
					}
			
					array_multisort($points, SORT_DESC, $done, SORT_ASC, $teams);
				}
			}
            updateRanking( $league_id, $season, $group, $teams, $teamsTmp );
		}

		return true;
	}
	

	/**
	 * determine if two teams are tied
	 *
	 * @param object $team
	 * @param object $team2
	 * @return boolean
	 */
	function isTie( $team, $team2 )
	{
//    echo "Check for tie here1 <br>";
		if ( $team->points['plus'] == $team2->points['plus'] && $team->diff == $team2->diff && $team->points2['plus'] == $team2->points2['plus'] )
			return true;

		return false;
	}

	
	/**
	 * gets matches from database
	 * 
	 * @param string $search (optional)
	 * @param int $limit (optional)
	 * @param string $order (optional)
	 * @param string $output (optional)
	 * @return array
	 */
	function getMatches( $search = false, $limit = false, $order = false, $output = 'OBJECT' )
	{
	 	global $wpdb;
	
		if ( !$order ) $order = "`date` ASC";

		$sql = "SELECT `group`, `home_team`, `away_team`, DATE_FORMAT(`date`, '%Y-%m-%d %H:%i') AS date, DATE_FORMAT(`date`, '%e') AS day, DATE_FORMAT(`date`, '%c') AS month, DATE_FORMAT(`date`, '%Y') AS year, DATE_FORMAT(`date`, '%H') AS `hour`, DATE_FORMAT(`date`, '%i') AS `minutes`, `match_day`, `location`, `league_id`, `home_points`, `away_points`, `winner_id`, `loser_id`, `post_id`, `season`, `id`, `custom` FROM {$wpdb->leaguemanager_matches}";
		if ( $search ) $sql .= " WHERE $search";
		$sql .= " ORDER BY $order";
		if ( $limit ) $sql .= " LIMIT 0,".$limit."";
		
		$matches = $wpdb->get_results( $sql, $output );

		$i = 0;
		foreach ( $matches AS $match ) {
			$matches[$i]->custom = $match->custom = maybe_unserialize($match->custom);
			$matches[$i]->custom = $match->custom = stripslashes_deep($match->custom);
			$matches[$i] = (object)array_merge((array)$match, (array)$match->custom);
		//	unset($matches[$i]->custom);

			$i++;
		}
		return $matches;
	}
	
	
	/**
	 * get single match
	 *
	 * @param int $match_id
	 * @return object
	 */
	function getMatch( $match_id )
	{
		global $wpdb;

		$match = $wpdb->get_results( "SELECT `group`, `home_team`, `away_team`, DATE_FORMAT(`date`, '%Y-%m-%d %H:%i') AS date, DATE_FORMAT(`date`, '%e') AS day, DATE_FORMAT(`date`, '%c') AS month, DATE_FORMAT(`date`, '%Y') AS year, DATE_FORMAT(`date`, '%H') AS `hour`, DATE_FORMAT(`date`, '%i') AS `minutes`, `match_day`, `location`, `league_id`, `home_points`, `away_points`, `winner_id`, `loser_id`, `post_id`, `season`, `id`, `custom` FROM {$wpdb->leaguemanager_matches} WHERE `id` = {$match_id}" );
		$match = $match[0];

		$match->custom = maybe_unserialize($match->custom);
		$match->custom = stripslashes_deep($match->custom);
		$match = (object)array_merge((array)$match, (array)$match->custom);
		//unset($match->custom);

		return $match;
	}
	
	
	/**
	 * get match title
	 *
	 * @param int $match_id
	 * @param boolean show_logo
	 *
	 */
	function getMatchTitle( $match_id, $show_logo = true)
	{
		$match = $this->getMatch($match_id);
		$league = $this->getLeague($match->league_id);
		$teams = $this->getTeams("`league_id` = '".$match->league_id."' AND `season` = '".$match->season."'", false, 'ARRAY');

		if (!isset($teams[$match->home_team]) || !isset($teams[$match->away_team]) || $match->home_team == $match->away_team) {
			if (isset($match->title))
				$title = $match->title;
			else
				$title = "";
		} else {
			$home_logo_img = ($teams[$match->home_team]['logo'] != "" && $show_logo) ? "<img src='".$this->getThumbnailUrl($teams[$match->home_team]['logo'])."' alt='' />" : "";
			$away_logo_img = ($teams[$match->away_team]['logo'] != "" && $show_logo) ? "<img src='".$this->getThumbnailUrl($teams[$match->away_team]['logo'])."' alt='' />" : "";
			$home_team_name = ($this->isHomeTeamMatch($match->home_team, $match->away_team, $teams)) ? "<strong>".$teams[$match->home_team]['title']."</strong>" : $teams[$match->home_team]['title']; 
			$away_team_name = ($this->isHomeTeamMatch($match->home_team, $match->away_team, $teams)) ? "<strong>".$teams[$match->away_team]['title']."</strong>" : $teams[$match->away_team]['title']; 
		
			$title = sprintf("%s %s &#8211; %s %s", $home_team_name, $home_logo_img, $away_logo_img, $away_team_name);
			$title = apply_filters( 'leaguemanager_matchtitle_'.$league->sport, $title, $match, $teams );
		}
		
		return $title;
	}
	
	
	/**
	 * test if it's a match of home team
	 *
	 * @param int $home_team
	 * @param int $away_team
	 * @param array $teams
	 * @return boolean
	 */
	function isHomeTeamMatch( $home_team, $away_team, $teams )
	{
		if ( isset($teams[$home_team]) && 1 == $teams[$home_team]['home'] )
			return true;
		elseif ( isset($teams[$away_team]) && 1 == $teams[$away_team]['home'] )
			return true;
		else
			return false;
	}


	/**
	 * get card name
	 *
	 * @param string $type
	 * @return nice card name
	 */
	function getCards( $type = false )
	{
		$cards = array( 'red' => __( 'Red', 'leaguemanager' ), 'yellow' => __( 'Yellow', 'leaguemanager' ), 'yellow-red' => __( 'Yellow/Red', 'leaguemanager' ) );
		$cards = apply_filters( 'leaguemanager_cards', $cards );

		if ( $type )
			return $cards[$type];
		else
			return $cards;
	}
	
	function lm_pagination($paged, $pages = '', $range = 4) {
		$showitems = ($range * 2)+1;
	
		if(empty($paged)) $paged = 1;
		if($pages == '') {
			global $wp_query;
			$pages = $wp_query->max_num_pages;
			if(!$pages) {
				$pages = 1;
			}
		}

		$div_output = '';
		if (1 != $pages) {
			$div_output .= "<ul class='pagination'>";
			if($paged > 2 && $paged > $range+1 && $showitems < $pages) $div_output .= "<li><a href='".get_pagenum_link(1)."' class='first_page'>&laquo; First</a></li>";
			if($paged > 1) $div_output .= "<li><a href='".get_pagenum_link($paged - 1)."' class='prev_page'>&lsaquo; Previous</a></li>";
				
			for ($i=1; $i <= $pages; $i++) {
				if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
					$div_output .= ($paged == $i)? "<li class='active'><a href=''>".$i."</a></li>":"<li><a href='".get_pagenum_link($i)."' class='inactive'>".$i."</a></li>";
				}
			}
	
			if ($paged < $pages) $div_output .= "<li><a href='".get_pagenum_link($paged + 1)."' class='next_page'>Next &rsaquo;</a></li>";
			if ($paged < $pages-1 && $paged+$range-1 < $pages && $showitems < $pages) $div_output .= "<li><a href='".get_pagenum_link($pages)."' class='last_page'>Last &raquo;</a></li>";
			$div_output .= "</ul>\n";
		}
		return $div_output;
	}
}
?>
