<div class="codex">

	<img class="spLeft" src="<?php echo SPCOMMONIMAGES; ?>custom-theme.png" alt="" title="" />
	<div class="codex-head">Customisation Service</div>
	<div class="clearboth"></div>

	<p class="codex-sub">Do you need a custom forum theme?<br /></p>
	<p>Simple:Press is totally customisable and most changes can be made simply
	but for that extra something - to match your WP theme perhaps - we can help.</p>
	<p>We can also create custom icon sets for you forums and groups and they can really
	ake your forunm stand out.</p>
	<p>For details please visit <a href="<?php echo SPHOMESITE; ?>/custom-simplepress-themes-for-every-need/">
	Custom Themes</a> and <a href="<?php echo SPHOMESITE; ?>/custom-simplepress-plugin-development-services/">
	Custom Plugins</a></p>

</div>
