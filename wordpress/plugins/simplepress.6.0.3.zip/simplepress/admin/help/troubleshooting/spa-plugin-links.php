<div class="codex">

	<img class="spLeft" src="<?php echo SPCOMMONIMAGES; ?>plugin.png" alt="" title="" />
	<div class="codex-head">Simple:Press Plugins</div>
	<div class="clearboth"></div>

	<p>Please visit our <a href="<?php echo(SPHOMESITE); ?>/store/plugins/">Plugin Library</a></p>
	<p>With very nearly 70 plugins available there is something every forum administrator needs in our plugin library
	from Subscriptions to Post Editors, Private Messaging to Polls, File and Image Uploading to enhanced Search.</p>

</div>
