<div class="codex">

	<img class="spLeft" src="<?php echo SPCOMMONIMAGES; ?>member.png" alt="" title="" />
	<div class="codex-head">Premium Simple:Press Support</div>
	<div class="clearboth"></div>

	<p class="codex-sub">Want that extra level of support?<br /></p>
	<p>Premium support gains you full access to our support forums where our user-praised response times will
	help you get the best out of Simple:Press.</p>
	<p>And for those who want to get into the code to perform some serious customisation - our developer documentation provides
	extensive and growing details of the full Simple:Press API.</p>
	<p>For membership plan options please visit the <a href="<?php echo SPHOMESITE; ?>/store/memberships/" >
	Simple:Press Membership Plans</a></p>

</div>
