<div class="codex">

	<img class="spLeft" src="<?php echo SPCOMMONIMAGES; ?>theme.png" alt="" title="" />
	<div class="codex-head">Simple:Press Themes</div>
	<div class="clearboth"></div>

	<p>Please visit our <a href="<?php echo(SPHOMESITE); ?>/store/themes/">Theme Library</a></p>
	<p>Check out our small but growing library of themes and - in particular - you will find our most recent
	premium and fully responsive offerings to help your users who prefer to use mobile phones and tablets.</p>


</div>
