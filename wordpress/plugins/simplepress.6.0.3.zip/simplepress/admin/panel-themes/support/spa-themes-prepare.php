<?php
/*
Simple:Press
Admin Themes prepare Support Functions
$LastChangedDate: 2017-01-07 13:28:47 -0600 (Sat, 07 Jan 2017) $
$Rev: 14996 $
*/

if (preg_match('#'.basename(__FILE__).'#', $_SERVER['PHP_SELF'])) die('Access denied - you cannot directly call this file');

