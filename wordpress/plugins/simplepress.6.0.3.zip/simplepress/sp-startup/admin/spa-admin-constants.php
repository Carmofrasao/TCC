<?php
/**
 * Admin Core Constants
 * This file loads at admin core level - all admin pages
 *
 * $LastChangedDate: 2017-01-13 11:13:51 -0600 (Fri, 13 Jan 2017) $
 * $Rev: 15029 $
 */
