<?php
/**
 * Deprecated code
 * This file loads at core level - all page loads for admin and front
 *
 * $LastChangedDate: 2016-12-25 18:24:07 -0600 (Sun, 25 Dec 2016) $
 * $Rev: 14902 $
 */
if (preg_match('#'.basename(__FILE__).'#', $_SERVER['PHP_SELF'])) die('Access denied - you cannot directly call this file');
