<?php
print( '<div class="promo-area">
	<a target="_blank" href="https://codecanyon.net/item/modal-survey-wordpress-poll-survey-quiz-plugin/6533863?ref=pantherius&utm_medium=wordpress&utm_campaign=wordpress-plugins&utm_content=wp_sidebar_modal_survey&utm_source=WordPress%20Admin%20ModalSurvey&utm_term=SideBar%20Panel%20MSAD"><img src="http://static.pantherius.com/modal-survey/preview-horizontal.jpg"></a>
	<a target="_blank" href="https://codecanyon.net/item/w8-contact-form-wordpress-contact-form-plugin/9661063?ref=pantherius&utm_medium=wordpress&utm_campaign=wordpress-plugins&utm_content=wp_sidebar_w8_contact_form&utm_source=WordPress%20Admin%20ModalSurvey&utm_term=SideBar%20Panel%20W8AD"><img src="http://static.pantherius.com/wordpress-contact-form/preview-horizontal.jpg"></a>
</div>' );
?>


